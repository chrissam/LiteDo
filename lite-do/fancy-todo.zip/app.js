// Todo App JavaScript - Fixed Version
class TodoApp {
    constructor() {
        this.tasks = [];
        this.currentFilter = 'all';
        this.currentSearch = '';
        this.currentSort = 'createdDate';
        this.selectedTasks = new Set();
        this.activeTag = null;
        this.showCompleted = true;
        this.subtasks = [];
        
        this.init();
    }

    init() {
        this.loadData();
        this.bindEvents();
        this.render();
        this.updateCounts();
    }

    // Load data from localStorage or use sample data
    loadData() {
        const storedTasks = localStorage.getItem('fancyTasks');
        if (storedTasks) {
            try {
                this.tasks = JSON.parse(storedTasks);
            } catch (e) {
                console.error('Error parsing stored tasks:', e);
                this.loadSampleData();
            }
        } else {
            this.loadSampleData();
        }
    }

    // Load sample data
    loadSampleData() {
        this.tasks = [
            {
                id: "1",
                title: "Build to-do app in python",
                description: "Build a useful to-do app for your use.",
                completed: false,
                priority: "High",
                dueDate: "2025-08-12",
                tags: ["work", "development"],
                createdDate: "2025-08-10",
                subtasks: []
            },
            {
                id: "2", 
                title: "Review project architecture",
                description: "Prepare resiliency gap analysis",
                completed: false,
                priority: "High", 
                dueDate: "2025-08-12",
                tags: ["work", "autodesk"],
                createdDate: "2025-08-11",
                subtasks: []
            },
            {
                id: "3",
                title: "Refactor billing module", 
                description: "Fix rounding bug and add tests",
                completed: false,
                priority: "Med",
                dueDate: "2025-08-15", 
                tags: ["work"],
                createdDate: "2025-08-12",
                subtasks: []
            }
        ];
        this.saveData();
    }

    // Save data to localStorage
    saveData() {
        try {
            localStorage.setItem('fancyTasks', JSON.stringify(this.tasks));
        } catch (e) {
            console.error('Error saving tasks:', e);
        }
    }

    // Bind event listeners
    bindEvents() {
        // Add task form
        const addTaskForm = document.getElementById('addTaskForm');
        if (addTaskForm) {
            addTaskForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addTask();
            });
        }

        // Search
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.currentSearch = e.target.value.toLowerCase();
                this.render();
                this.toggleClearSearch();
            });
        }

        // Clear search
        const clearSearchBtn = document.getElementById('clearSearchBtn');
        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', () => {
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.value = '';
                }
                this.currentSearch = '';
                this.render();
                this.toggleClearSearch();
            });
        }

        // Navigation filters
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');
                this.currentFilter = item.dataset.filter;
                this.render();
            });
        });

        // Show completed checkbox
        const showCompleted = document.getElementById('showCompleted');
        if (showCompleted) {
            showCompleted.addEventListener('change', (e) => {
                this.showCompleted = e.target.checked;
                this.render();
            });
        }

        // Sort dropdown
        const sortBy = document.getElementById('sortBy');
        if (sortBy) {
            sortBy.addEventListener('change', (e) => {
                this.currentSort = e.target.value;
                this.render();
            });
        }

        // Bulk actions
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                this.toggleSelectAll(e.target.checked);
            });
        }

        const markDoneBtn = document.getElementById('markDoneBtn');
        if (markDoneBtn) {
            markDoneBtn.addEventListener('click', () => {
                this.markSelectedDone();
            });
        }

        const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
        if (deleteSelectedBtn) {
            deleteSelectedBtn.addEventListener('click', () => {
                this.deleteSelected();
            });
        }

        // Add subtask
        const addSubtaskBtn = document.getElementById('addSubtaskBtn');
        if (addSubtaskBtn) {
            addSubtaskBtn.addEventListener('click', () => {
                this.showSubtaskContainer();
            });
        }

        // Analytics modal
        const analyticsBtn = document.getElementById('analyticsBtn');
        if (analyticsBtn) {
            analyticsBtn.addEventListener('click', () => {
                this.showAnalytics();
            });
        }

        const closeAnalyticsBtn = document.getElementById('closeAnalyticsBtn');
        if (closeAnalyticsBtn) {
            closeAnalyticsBtn.addEventListener('click', () => {
                this.hideModal('analyticsModal');
            });
        }

        // Edit modal
        const editTaskForm = document.getElementById('editTaskForm');
        if (editTaskForm) {
            editTaskForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveEditedTask();
            });
        }

        const closeEditBtn = document.getElementById('closeEditBtn');
        if (closeEditBtn) {
            closeEditBtn.addEventListener('click', () => {
                this.hideModal('editTaskModal');
            });
        }

        const cancelEditBtn = document.getElementById('cancelEditBtn');
        if (cancelEditBtn) {
            cancelEditBtn.addEventListener('click', () => {
                this.hideModal('editTaskModal');
            });
        }

        // Export and Reset
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportTasks();
            });
        }

        const resetBtn = document.getElementById('resetBtn');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetApp();
            });
        }

        // Modal backdrop clicks
        const analyticsModal = document.getElementById('analyticsModal');
        if (analyticsModal) {
            analyticsModal.addEventListener('click', (e) => {
                if (e.target.classList.contains('modal')) {
                    this.hideModal('analyticsModal');
                }
            });
        }

        const editTaskModal = document.getElementById('editTaskModal');
        if (editTaskModal) {
            editTaskModal.addEventListener('click', (e) => {
                if (e.target.classList.contains('modal')) {
                    this.hideModal('editTaskModal');
                }
            });
        }
    }

    // Generate unique ID
    generateId() {
        return Date.now().toString() + Math.random().toString(36).substr(2, 9);
    }

    // Get current date in YYYY-MM-DD format
    getCurrentDate() {
        return new Date().toISOString().split('T')[0];
    }

    // Add new task
    addTask() {
        const titleInput = document.getElementById('taskTitle');
        const descriptionInput = document.getElementById('taskDescription');
        const dueDateInput = document.getElementById('taskDueDate');
        const priorityInput = document.getElementById('taskPriority');
        const tagsInput = document.getElementById('taskTags');

        if (!titleInput || !descriptionInput || !dueDateInput || !priorityInput || !tagsInput) {
            console.error('Form elements not found');
            return;
        }

        const title = titleInput.value.trim();
        const description = descriptionInput.value.trim();
        const dueDate = dueDateInput.value;
        const priority = priorityInput.value;
        const tagsInputValue = tagsInput.value.trim();
        const tags = tagsInputValue ? tagsInputValue.split(',').map(tag => tag.trim()).filter(tag => tag) : [];

        if (!title) {
            alert('Please enter a task title');
            return;
        }

        const newTask = {
            id: this.generateId(),
            title,
            description,
            completed: false,
            priority,
            dueDate,
            tags,
            createdDate: this.getCurrentDate(),
            subtasks: [...this.subtasks]
        };

        this.tasks.unshift(newTask);
        this.saveData();
        this.clearForm();
        this.render();
        this.updateCounts();
    }

    // Clear add task form
    clearForm() {
        const form = document.getElementById('addTaskForm');
        if (form) {
            form.reset();
        }
        this.subtasks = [];
        const subtasksContainer = document.getElementById('subtasksContainer');
        if (subtasksContainer) {
            subtasksContainer.style.display = 'none';
            subtasksContainer.innerHTML = '';
        }
    }

    // Show subtask container
    showSubtaskContainer() {
        const container = document.getElementById('subtasksContainer');
        if (container) {
            container.style.display = 'block';
            this.addSubtaskInput();
        }
    }

    // Add subtask input
    addSubtaskInput() {
        const container = document.getElementById('subtasksContainer');
        if (!container) return;

        const subtaskDiv = document.createElement('div');
        subtaskDiv.className = 'subtask-item';
        
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'subtask-input';
        input.placeholder = 'Enter subtask...';
        
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'remove-subtask';
        removeBtn.innerHTML = '×';
        removeBtn.addEventListener('click', () => {
            subtaskDiv.remove();
            this.updateSubtasks();
        });

        input.addEventListener('input', () => {
            this.updateSubtasks();
        });
        
        subtaskDiv.appendChild(input);
        subtaskDiv.appendChild(removeBtn);
        container.appendChild(subtaskDiv);
    }

    // Update subtasks array
    updateSubtasks() {
        const inputs = document.querySelectorAll('.subtask-input');
        this.subtasks = Array.from(inputs).map(input => input.value.trim()).filter(text => text);
    }

    // Toggle task completion
    toggleTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            task.completedDate = task.completed ? this.getCurrentDate() : null;
            this.saveData();
            this.render();
            this.updateCounts();
        }
    }

    // Delete task
    deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.selectedTasks.delete(taskId);
            this.saveData();
            this.render();
            this.updateCounts();
        }
    }

    // Edit task
    editTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            const editTaskId = document.getElementById('editTaskId');
            const editTaskTitle = document.getElementById('editTaskTitle');
            const editTaskDescription = document.getElementById('editTaskDescription');
            const editTaskDueDate = document.getElementById('editTaskDueDate');
            const editTaskPriority = document.getElementById('editTaskPriority');
            const editTaskTags = document.getElementById('editTaskTags');

            if (editTaskId) editTaskId.value = task.id;
            if (editTaskTitle) editTaskTitle.value = task.title;
            if (editTaskDescription) editTaskDescription.value = task.description;
            if (editTaskDueDate) editTaskDueDate.value = task.dueDate;
            if (editTaskPriority) editTaskPriority.value = task.priority;
            if (editTaskTags) editTaskTags.value = task.tags.join(', ');

            this.showModal('editTaskModal');
        }
    }

    // Save edited task
    saveEditedTask() {
        const editTaskId = document.getElementById('editTaskId');
        if (!editTaskId) return;

        const taskId = editTaskId.value;
        const task = this.tasks.find(t => t.id === taskId);
        
        if (task) {
            const editTaskTitle = document.getElementById('editTaskTitle');
            const editTaskDescription = document.getElementById('editTaskDescription');
            const editTaskDueDate = document.getElementById('editTaskDueDate');
            const editTaskPriority = document.getElementById('editTaskPriority');
            const editTaskTags = document.getElementById('editTaskTags');

            if (editTaskTitle) task.title = editTaskTitle.value.trim();
            if (editTaskDescription) task.description = editTaskDescription.value.trim();
            if (editTaskDueDate) task.dueDate = editTaskDueDate.value;
            if (editTaskPriority) task.priority = editTaskPriority.value;
            if (editTaskTags) {
                const tagsInputValue = editTaskTags.value.trim();
                task.tags = tagsInputValue ? tagsInputValue.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
            }
            
            this.saveData();
            this.hideModal('editTaskModal');
            this.render();
            this.updateCounts();
        }
    }

    // Show modal
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    // Hide modal
    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    // Toggle select all tasks
    toggleSelectAll(checked) {
        const filteredTasks = this.getFilteredTasks();
        if (checked) {
            filteredTasks.forEach(task => this.selectedTasks.add(task.id));
        } else {
            this.selectedTasks.clear();
        }
        this.updateSelectedCount();
        this.render();
    }

    // Toggle task selection
    toggleTaskSelection(taskId, checked) {
        if (checked) {
            this.selectedTasks.add(taskId);
        } else {
            this.selectedTasks.delete(taskId);
        }
        this.updateSelectedCount();
    }

    // Update selected count
    updateSelectedCount() {
        const selectedCount = document.getElementById('selectedCount');
        if (selectedCount) {
            selectedCount.textContent = `Selected ${this.selectedTasks.size}`;
        }
    }

    // Mark selected tasks as done
    markSelectedDone() {
        this.selectedTasks.forEach(taskId => {
            const task = this.tasks.find(t => t.id === taskId);
            if (task && !task.completed) {
                task.completed = true;
                task.completedDate = this.getCurrentDate();
            }
        });
        this.selectedTasks.clear();
        this.saveData();
        this.render();
        this.updateCounts();
        this.updateSelectedCount();
    }

    // Delete selected tasks
    deleteSelected() {
        if (this.selectedTasks.size === 0) return;
        
        if (confirm(`Are you sure you want to delete ${this.selectedTasks.size} selected tasks?`)) {
            this.tasks = this.tasks.filter(t => !this.selectedTasks.has(t.id));
            this.selectedTasks.clear();
            this.saveData();
            this.render();
            this.updateCounts();
            this.updateSelectedCount();
        }
    }

    // Get filtered and sorted tasks
    getFilteredTasks() {
        let filtered = [...this.tasks];

        // Filter by search
        if (this.currentSearch) {
            filtered = filtered.filter(task => 
                task.title.toLowerCase().includes(this.currentSearch) ||
                task.description.toLowerCase().includes(this.currentSearch) ||
                task.tags.some(tag => tag.toLowerCase().includes(this.currentSearch))
            );
        }

        // Filter by active tag
        if (this.activeTag) {
            filtered = filtered.filter(task => task.tags.includes(this.activeTag));
        }

        // Filter by completion status
        if (!this.showCompleted) {
            filtered = filtered.filter(task => !task.completed);
        }

        // Filter by category
        const today = this.getCurrentDate();
        switch (this.currentFilter) {
            case 'today':
                filtered = filtered.filter(task => task.dueDate === today && !task.completed);
                break;
            case 'upcoming':
                filtered = filtered.filter(task => task.dueDate > today && !task.completed);
                break;
            case 'overdue':
                filtered = filtered.filter(task => task.dueDate && task.dueDate < today && !task.completed);
                break;
            case 'completed':
                filtered = filtered.filter(task => task.completed);
                break;
        }

        // Sort tasks
        filtered.sort((a, b) => {
            switch (this.currentSort) {
                case 'priority':
                    const priorityOrder = { 'High': 3, 'Med': 2, 'Low': 1 };
                    return priorityOrder[b.priority] - priorityOrder[a.priority];
                case 'dueDate':
                    if (!a.dueDate && !b.dueDate) return 0;
                    if (!a.dueDate) return 1;
                    if (!b.dueDate) return -1;
                    return new Date(a.dueDate) - new Date(b.dueDate);
                case 'createdDate':
                default:
                    return new Date(b.createdDate) - new Date(a.createdDate);
            }
        });

        return filtered;
    }

    // Get all unique tags
    getAllTags() {
        const tags = new Set();
        this.tasks.forEach(task => {
            task.tags.forEach(tag => tags.add(tag));
        });
        return Array.from(tags).sort();
    }

    // Format date for display
    formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        if (dateString === this.getCurrentDate()) {
            return 'Today';
        } else if (dateString === tomorrow.toISOString().split('T')[0]) {
            return 'Tomorrow';
        } else {
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        }
    }

    // Get due date class
    getDueDateClass(dueDate) {
        if (!dueDate) return '';
        const today = this.getCurrentDate();
        if (dueDate < today) return 'overdue';
        if (dueDate === today) return 'today';
        return '';
    }

    // Toggle clear search button visibility
    toggleClearSearch() {
        const clearBtn = document.getElementById('clearSearchBtn');
        if (clearBtn) {
            clearBtn.style.display = this.currentSearch ? 'inline-flex' : 'none';
        }
    }

    // Render task list
    render() {
        const filteredTasks = this.getFilteredTasks();
        const taskList = document.getElementById('taskList');
        
        if (!taskList) return;

        if (filteredTasks.length === 0) {
            taskList.innerHTML = `
                <div class="empty-state">
                    <h3>No tasks found</h3>
                    <p>Try adjusting your filters or add a new task.</p>
                </div>
            `;
        } else {
            taskList.innerHTML = filteredTasks.map(task => `
                <div class="task-item ${task.completed ? 'completed' : ''}">
                    <label class="checkbox-label task-checkbox">
                        <input type="checkbox" ${this.selectedTasks.has(task.id) ? 'checked' : ''} 
                               onchange="window.app.toggleTaskSelection('${task.id}', this.checked)">
                        <span class="checkbox-custom"></span>
                    </label>
                    
                    <div class="task-content">
                        <div class="task-title">${this.escapeHtml(task.title)}</div>
                        ${task.description ? `<div class="task-description">${this.escapeHtml(task.description)}</div>` : ''}
                        
                        <div class="task-meta">
                            <span class="priority-badge priority-${task.priority.toLowerCase()}">${task.priority}</span>
                            ${task.dueDate ? `<span class="due-date ${this.getDueDateClass(task.dueDate)}">${this.formatDate(task.dueDate)}</span>` : ''}
                        </div>
                        
                        ${task.tags.length > 0 ? `
                            <div class="task-tags">
                                ${task.tags.map(tag => `<span class="task-tag">${this.escapeHtml(tag)}</span>`).join('')}
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="task-actions">
                        <button class="task-action-btn complete" onclick="window.app.toggleTask('${task.id}')" title="Toggle completion">
                            ${task.completed ? '↶' : '✓'}
                        </button>
                        <button class="task-action-btn edit" onclick="window.app.editTask('${task.id}')" title="Edit task">
                            ✎
                        </button>
                        <button class="task-action-btn delete" onclick="window.app.deleteTask('${task.id}')" title="Delete task">
                            🗑
                        </button>
                    </div>
                </div>
            `).join('');
        }

        this.renderTags();
        this.updateStats();
    }

    // Render tags
    renderTags() {
        const tags = this.getAllTags();
        const tagsContainer = document.getElementById('tagsContainer');
        
        if (!tagsContainer) return;

        if (tags.length === 0) {
            tagsContainer.innerHTML = '<p style="color: var(--color-text-secondary); font-size: var(--font-size-xs);">No tags yet</p>';
        } else {
            tagsContainer.innerHTML = tags.map(tag => `
                <button class="tag-pill ${this.activeTag === tag ? 'active' : ''}" onclick="window.app.toggleTag('${tag}')">
                    ${this.escapeHtml(tag)}
                </button>
            `).join('');
        }
    }

    // Toggle tag filter
    toggleTag(tag) {
        this.activeTag = this.activeTag === tag ? null : tag;
        this.render();
    }

    // Update counts
    updateCounts() {
        const today = this.getCurrentDate();
        
        const counts = {
            all: this.tasks.length,
            today: this.tasks.filter(t => t.dueDate === today && !t.completed).length,
            upcoming: this.tasks.filter(t => t.dueDate > today && !t.completed).length,
            overdue: this.tasks.filter(t => t.dueDate && t.dueDate < today && !t.completed).length,
            completed: this.tasks.filter(t => t.completed).length
        };

        Object.entries(counts).forEach(([key, count]) => {
            const element = document.getElementById(`${key}Count`);
            if (element) {
                element.textContent = count;
            }
        });
    }

    // Update stats in header
    updateStats() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(t => t.completed).length;
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
        
        const taskStats = document.getElementById('taskStats');
        if (taskStats) {
            taskStats.textContent = `${total} tasks, ${percentage}% complete`;
        }
    }

    // Show analytics
    showAnalytics() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(t => t.completed).length;
        const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;
        const overdue = this.tasks.filter(t => t.dueDate && t.dueDate < this.getCurrentDate() && !t.completed).length;
        const today = this.tasks.filter(t => t.dueDate === this.getCurrentDate() && !t.completed).length;

        const elements = {
            completionRate: document.getElementById('completionRate'),
            overdueTasksCount: document.getElementById('overdueTasksCount'),
            todayTasksCount: document.getElementById('todayTasksCount'),
            totalTasksCount: document.getElementById('totalTasksCount')
        };

        if (elements.completionRate) elements.completionRate.textContent = `${completionRate}%`;
        if (elements.overdueTasksCount) elements.overdueTasksCount.textContent = overdue;
        if (elements.todayTasksCount) elements.todayTasksCount.textContent = today;
        if (elements.totalTasksCount) elements.totalTasksCount.textContent = total;

        this.showModal('analyticsModal');
    }

    // Export tasks
    exportTasks() {
        const data = {
            exportDate: new Date().toISOString(),
            tasks: this.tasks
        };
        
        try {
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `fancy-tasks-export-${this.getCurrentDate()}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            alert('Tasks exported successfully!');
        } catch (e) {
            console.error('Export error:', e);
            alert('Export failed. Please try again.');
        }
    }

    // Reset app
    resetApp() {
        if (confirm('Are you sure you want to reset all tasks? This will restore the original sample tasks.')) {
            this.loadSampleData();
            this.selectedTasks.clear();
            this.currentSearch = '';
            this.activeTag = null;
            this.currentFilter = 'all';
            
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = '';
            }

            // Reset active navigation
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            const allNavItem = document.querySelector('.nav-item[data-filter="all"]');
            if (allNavItem) {
                allNavItem.classList.add('active');
            }

            this.render();
            this.updateCounts();
            this.updateSelectedCount();
            this.toggleClearSearch();
        }
    }

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new TodoApp();
});